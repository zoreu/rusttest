use actix_web::{get, App, HttpServer, Responder, HttpResponse};
use std::env;

#[get("/")]
async fn index() -> impl Responder {
    HttpResponse::Ok().body("Hello, Rust Web!")
}

#[actix_web::main]
async fn main() -> std::io::Result<()> {
    // Obtém argumentos passados na linha de comando
    let args: Vec<String> = env::args().collect();

    // Procura pelo argumento "--port" e pega o valor seguinte
    let mut port = "8080".to_string(); // Padrão: 8080
    if let Some(i) = args.iter().position(|arg| arg == "--port") {
        if let Some(value) = args.get(i + 1) {
            port = value.clone();
        }
    }

    let addr = format!("0.0.0.0:{}", port);
    println!("🚀 Servidor rodando em: {}", addr);

    HttpServer::new(|| App::new().service(index))
        .bind(addr)?
        .run()
        .await
}
